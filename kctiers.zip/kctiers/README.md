# Kraken
Kraken is an Asic resistant,Community Focused,Secure and Decentralized Cryptocurrency.
Pow phase will start on 02 February, 2018 at 11:00 UTC.
